class Color:
    RESET = "\033[0m"
    CYAN = "\033[1;36;40m"
    GREEN = "\033[1;32;40m"
    RED = "\033[1;31;40m"
    YELLOW = '\033[1;33;40m'