from PyPDF2 import PdfFileReader
import sys
from color import Color
import warnings

# Filter out PyPDF2 warnings
warnings.filterwarnings("ignore", category=UserWarning, module="PyPDF2")


def format_date(date_str):
    # Date format in PDF metadata: 'D:YYYYMMDDHHmmSS'
    return f"{date_str[6:8]}-{date_str[4:6]}-{date_str[2:4]} {date_str[8:10]}:{date_str[10:12]}:{date_str[12:14]}"

def pdfinfo():
    try:
        file_path = input(Color.YELLOW + "Enter PDF File path: " + Color.RESET)
        with open(file_path, 'rb') as f:
            pdf = PdfFileReader(f)
            info = pdf.getDocumentInfo()
            number_of_pages = pdf.getNumPages()

            if info:
                print(Color.GREEN + "[+] PDF Information:")
                if '/Author' in info:
                    print(Color.GREEN + "[+] Author        :", info.author)
                
                if '/Creator' in info:
                    print(Color.GREEN + "[+] Creator       :", info.creator)
                
                if '/Producer' in info:
                    print(Color.GREEN + "[+] Producer      :", info.producer)
                
                if '/Title' in info:
                    print(Color.GREEN + "[+] Title         :", info.title)
                
                if '/CreationDate' in info:
                    creation_date = format_date(info['/CreationDate'])
                    print(Color.GREEN + "[+] Creation Date :", creation_date)

                
                if '/ModDate' in info:
                    modified_date = format_date(info['/ModDate'])
                    print(Color.CYAN + "[+] Modified Date :", modified_date)

                print(Color.CYAN + "[+] Number of Pages:", number_of_pages)

                
            else:
                print(Color.RED + "[-] No metadata available." + Color.RESET)

    except FileNotFoundError:
        print(Color.RED + "[-] File not found." + Color.RESET)
    
    except KeyboardInterrupt:
        print(Color.RED + "\nProgram Interrupted by user." + Color.RESET)
        sys.exit(1)

    except Exception as e:
        print(Color.RED + "[-] An error occurred:", str(e), Color.RESET)

if __name__ == "__main__":
    pdfinfo()
